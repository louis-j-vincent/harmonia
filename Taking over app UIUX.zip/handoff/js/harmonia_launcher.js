/* ============================================================================
 * Harmonia — Launcher — replaces harmonia.html (delete the preview state-switcher in build())
 * Drop-in, dependency-free. Plain vanilla JS + DOM (no framework, no build).
 *
 * USE:
 *   <script src="harmonia_launcher.js"></script>
 *   <div id="hl-root"></div>
 *   (auto-initialises on DOM ready; styles are injected automatically.)
 *
 * DATA (swap for real Harmonia data — the shapes below are already what the
 * engine expects, so adapting is a rename, not a rewrite):
 *   PORT/SRV/CMD constants near the top.
 *   The demo data lives near the TOP of the engine section below. Replace it
 *   with your real values (or map P.chords/etc into the same shape).
 * ========================================================================== */
(function(){var s=document.createElement('style');s.textContent="\n  * { box-sizing: border-box; }\n  html, body { margin: 0; }\n  body { background: #efe7d6; }\n  a { color: #8a2b2b; } a:hover { color: #6f2020; }\n  @keyframes hl-breathe { 0%,100% { opacity: .5; transform: scale(1); } 50% { opacity: 1; transform: scale(1.25); } }\n  @keyframes hl-bar { 0%,100% { transform: scaleY(.4); } 50% { transform: scaleY(1); } }\n  @keyframes hl-in { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }\n  @keyframes hl-ring { 0% { transform: scale(.8); opacity: .55; } 100% { transform: scale(2.4); opacity: 0; } }\n";document.head.appendChild(s);})();


window.HLAUNCH = (function(){
  "use strict";
  const UI = "-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif";
  const SERIF = "Georgia,'Times New Roman',serif";
  const MONO = "'SF Mono','Fira Code',ui-monospace,Menlo,monospace";
  const T = { paper:"#f7f3e9", card:"#fffdf6", ink:"#1c1c1c", rule:"#b9b09a", faint:"#8a8371", accent:"#8a2b2b", line:"#e5dcc6", deep:"#2a2622", green:"#1f8a5b", amber:"#c58a2e" };
  const PORT = 7771, SRV = "http://localhost:" + PORT;
  const CMD = ".venv/bin/python scripts/harmonia_server.py";
  function el(tag,css,txt){ const e=document.createElement(tag); if(css)e.style.cssText=css; if(txt!=null)e.textContent=txt; return e; }

  const API = {};
  API.build = function(host){
    host.innerHTML = "";
    host.style.cssText = "min-height:100vh;display:flex;align-items:center;justify-content:center;padding:32px;background:radial-gradient(120% 90% at 50% 0%, #f4ecdb 0%, #efe7d6 55%, #e7dcc6 100%);font-family:"+UI+";";

    let phase = "checking", forced = null, pollTimer = null;

    const card = el("div", `position:relative;width:100%;max-width:430px;background:${T.card};border:1px solid ${T.line};border-radius:22px;padding:38px 34px 30px;box-shadow:0 30px 70px -30px rgba(60,42,22,.5), 0 2px 0 rgba(255,255,255,.6) inset;text-align:center;`);
    const brand = el("div", "margin-bottom:24px;");
    const logo = el("div", `font:italic 500 44px Georgia,serif;color:${T.ink};letter-spacing:0;line-height:1;`);
    logo.innerHTML = 'harmon<span style="color:'+T.accent+'">ia</span>';
    brand.appendChild(logo);
    brand.appendChild(el("div", `font:500 12.5px ${UI};color:${T.faint};margin-top:9px;`, "chord charts from any recording"));
    card.appendChild(brand);

    const pill = el("div", `display:inline-flex;align-items:center;gap:9px;background:${T.paper};border:1px solid ${T.line};border-radius:999px;padding:8px 15px 8px 13px;margin-bottom:22px;`);
    const dotWrap = el("span", "position:relative;display:inline-flex;width:11px;height:11px;");
    const dot = el("span", `width:11px;height:11px;border-radius:50%;background:${T.rule};position:relative;z-index:1;`);
    dotWrap.appendChild(dot);
    const statusTx = el("span", `font:600 13px ${UI};color:${T.ink};`);
    pill.appendChild(dotWrap); pill.appendChild(statusTx);
    card.appendChild(pill);

    const body = el("div", "");
    card.appendChild(body);
    host.appendChild(card);

    const prev = el("div", `position:fixed;left:50%;bottom:18px;transform:translateX(-50%);display:inline-flex;align-items:center;gap:6px;background:${T.deep};border-radius:999px;padding:5px 6px 5px 12px;box-shadow:0 8px 24px -10px rgba(0,0,0,.4);z-index:50;`);
    prev.appendChild(el("span", `font:600 10px ${UI};letter-spacing:.06em;text-transform:uppercase;color:rgba(247,243,233,.55);`, "preview"));
    [["checking","Checking"],["offline","Offline"],["online","Running"]].forEach(o=>{
      const b = el("button", `border:none;background:transparent;color:rgba(247,243,233,.7);font:600 11px ${UI};padding:5px 11px;border-radius:999px;cursor:pointer;`, o[1]);
      b._p = o[0];
      b.onclick=()=>{ forced=o[0]; clearTimeout(pollTimer); render(o[0]); };
      prev.appendChild(b);
    });
    host.appendChild(prev);
    function paintPrev(){ [...prev.querySelectorAll("button")].forEach(b=>{ const on=b._p===phase; b.style.background=on?T.accent:"transparent"; b.style.color=on?T.paper:"rgba(247,243,233,.7)"; }); }

    function setDot(color, breathe, ring){
      dot.style.background = color;
      dot.style.animation = breathe ? "hl-breathe 1.4s ease-in-out infinite" : "none";
      [...dotWrap.querySelectorAll(".hl-ring")].forEach(r=>r.remove());
      if(ring){ const r=el("span", `position:absolute;inset:0;border-radius:50%;background:${color};z-index:0;`); r.className="hl-ring"; r.style.animation="hl-ring 1.6s ease-out infinite"; dotWrap.appendChild(r); }
    }

    function render(p){
      phase = p; body.innerHTML = ""; paintPrev();
      if(p==="checking"){
        setDot(T.amber, true, false);
        statusTx.textContent = "Looking for Harmonia\u2026";
        const bars = el("div", `display:flex;align-items:flex-end;justify-content:center;gap:4px;height:34px;margin:14px 0 6px;animation:hl-in .3s both;`);
        for(let i=0;i<5;i++) bars.appendChild(el("span", `width:5px;height:100%;background:${T.rule};border-radius:3px;transform-origin:bottom;animation:hl-bar 1s ${i*0.12}s ease-in-out infinite;`));
        body.appendChild(bars);
        body.appendChild(el("div", `font:italic 13px ${SERIF};color:${T.faint};margin-top:8px;`, "checking localhost:" + PORT));
      } else if(p==="online"){
        setDot(T.green, false, true);
        statusTx.textContent = "Running on :" + PORT;
        const openBtn = el("a", `display:flex;align-items:center;justify-content:center;gap:8px;text-decoration:none;background:${T.accent};color:${T.paper};border-radius:13px;padding:16px;font:600 16px ${UI};margin:6px 0 4px;animation:hl-in .3s both;box-shadow:0 10px 26px -12px rgba(138,43,43,.7);`, "Open Harmonia \u2192");
        openBtn.href = SRV;
        body.appendChild(openBtn);
        body.appendChild(el("div", `font:italic 12.5px ${SERIF};color:${T.faint};margin-top:12px;`, forced==="online" ? "(preview \u2014 the real page opens this automatically)" : "taking you there\u2026"));
        if(forced!=="online") setTimeout(()=>{ location.href = SRV; }, 900);
      } else {
        setDot(T.amber, false, false);
        statusTx.textContent = "Not running yet";
        body.appendChild(el("div", `font:400 14.5px ${UI};color:${T.ink};line-height:1.55;margin-bottom:18px;animation:hl-in .3s both;`, "Start Harmonia from your terminal \u2014 this page opens itself the moment it\u2019s up, no refresh needed."));
        body.appendChild(el("div", `font:600 10px ${UI};letter-spacing:.08em;text-transform:uppercase;color:${T.faint};text-align:left;margin-bottom:6px;`, "from the repo root"));
        const code = el("button", `position:relative;display:block;width:100%;text-align:left;background:${T.deep};border:none;border-radius:11px;padding:14px 16px;cursor:pointer;`);
        code.appendChild(el("code", `display:block;font:13px ${MONO};color:#e7c9a0;white-space:nowrap;overflow-x:auto;padding-right:60px;`, CMD));
        const cp = el("span", `position:absolute;right:12px;top:50%;transform:translateY(-50%);font:600 10.5px ${UI};color:rgba(247,243,233,.55);`, "copy");
        code.appendChild(cp);
        code.onclick=()=>{ try{ navigator.clipboard.writeText(CMD); }catch(e){} cp.textContent="copied!"; cp.style.color=T.green; setTimeout(()=>{ cp.textContent="copy"; cp.style.color="rgba(247,243,233,.55)"; },1600); };
        body.appendChild(code);
        const foot = el("div", "display:flex;align-items:center;justify-content:space-between;margin-top:18px;");
        const watching = el("div", `display:inline-flex;align-items:center;gap:8px;font:500 12px ${UI};color:${T.faint};`);
        watching.appendChild(el("span", `width:8px;height:8px;border-radius:50%;background:${T.amber};animation:hl-breathe 1.4s ease-in-out infinite;`));
        watching.appendChild(el("span",null,"watching for it\u2026"));
        foot.appendChild(watching);
        const retry = el("button", `border:1px solid ${T.line};background:${T.paper};color:${T.accent};border-radius:9px;padding:8px 16px;font:600 12.5px ${UI};cursor:pointer;`, "Retry now");
        retry.onclick=()=>{ forced=null; check(); };
        foot.appendChild(retry);
        body.appendChild(foot);
      }
    }

    async function check(){
      if(forced){ render(forced); return; }
      render("checking");
      let ok = false;
      try { await fetch(SRV + "/", { mode:"no-cors", cache:"no-store", signal: (AbortSignal.timeout?AbortSignal.timeout(2500):undefined) }); ok = true; } catch(e){ ok = false; }
      if(forced){ render(forced); return; }
      if(ok) render("online");
      else { render("offline"); pollTimer = setTimeout(check, 3000); }
    }
    check();
  };
  return API;
})();


/* auto-init */
(function(){function boot(){if(window.HLAUNCH)window.HLAUNCH.build(document.getElementById("hl-root"));}if(document.readyState!=='loading'){setTimeout(boot,0);}else{document.addEventListener('DOMContentLoaded',boot);}})();
